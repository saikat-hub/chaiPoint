Move to http://llvm.org/docs/LibFuzzer.html

